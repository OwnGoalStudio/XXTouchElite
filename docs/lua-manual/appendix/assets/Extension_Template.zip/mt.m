﻿
/*

编译命令：
	xcrun -sdk iphoneos gcc -arch armv7 -arch arm64 -miphoneos-version-min=4.3 -O3 -std=c99 -I/opt/theos/include/ -c -o mt.o mt.m
    xcrun -sdk iphoneos gcc -arch armv7 -arch arm64 -miphoneos-version-min=4.3 -O3 -Wl,-segalign,4000 -framework Foundation -framework UIKit -bundle -undefined dynamic_lookup -o mt.so mt.o
	
签名命令：
    $THEOS/bin/ldid -S mt.so

得到的 mt.so 即可在 Lua 中引用：
	local mt = require "mt"
	print(mt.device_name())

*/

#include <stdio.h>
#include <stdlib.h>
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
#import <objc/runtime.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIDevice.h>

static int mt_get_device_name(lua_State *L)
{
    NSString *name = [[UIDevice currentDevice] name];
    const char * name_str = [name UTF8String];
    lua_pushstring(L, name_str);
    return 1;
}

static int mt_split(lua_State *L)
{
    const char * str = luaL_checkstring(L, 1);
    const char * sep = luaL_checkstring(L, 2);
    NSString * nsStr = [NSString stringWithUTF8String:str];
    NSString * nsSep = [NSString stringWithUTF8String:sep];
    NSArray *arr = [nsStr componentsSeparatedByString:nsSep];
    lua_createtable(L, [arr count], 0);
    for (int i = 0; i < [arr count]; ++i) {
        lua_pushstring(L, [arr[i] UTF8String]);
        lua_rawseti(L, -2, i + 1);
    }
    return 1;
}

//注册函数库
static const luaL_Reg mt_lib[] = {
    {"device_name", mt_get_device_name},    //获取设备名称
    {"split", mt_split},                    //分割字符串
    {NULL, NULL}
};

int luaopen_mt(lua_State *L)
{
    luaL_newlib(L, mt_lib);
    return 1;
}